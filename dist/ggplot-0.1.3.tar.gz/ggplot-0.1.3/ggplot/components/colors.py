

COLORS = [
    "black",
	"red",
	"green",
	"blue",
	"orange",
	"cyan",
	"white"
]

def color_gen():
	while True:
		for color in COLORS:
			yield color
