from scale import scale


class scale_x_continuous(scale):
    pass
