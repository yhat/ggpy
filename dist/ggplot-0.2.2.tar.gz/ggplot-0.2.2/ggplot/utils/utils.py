import matplotlib.pyplot as plt

def ggsave(plot, filename):
    print plot
    plt.savefig(filename)

