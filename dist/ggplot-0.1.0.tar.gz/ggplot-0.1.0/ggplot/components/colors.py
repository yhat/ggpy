

COLORS = [
	"red",
	"green",
	"blue",
	"orange",
	"cyan",
	"black",
	"white"
]

def color_gen():
	while True:
		for color in COLORS:
			yield color
