from scale import scale

class scale_y_continuous(scale):
    pass
