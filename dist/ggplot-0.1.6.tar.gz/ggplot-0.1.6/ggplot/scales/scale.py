
# default 1st argument is the label
class scale(object):
    VALID_SCALES = ['limits', 'breaks', 'trans']
    def __init__(self):
        pass
